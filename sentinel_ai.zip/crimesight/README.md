# CrimeSight AI — Crime Prediction Dashboard

A Streamlit-based crime analytics and AI prediction dashboard for India.

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

Place `crime_data.csv` in the same folder as `app.py`.

## Features
- Interactive heatmap on India (CartoDB dark tiles)
- Filters: city, hour, crime type, domain, gender, age, weapon
- AI Risk Predictor (Random Forest, 120 estimators)
- 6 analytics charts: hourly bar, crime type donut, city bar, weapon bar, age histogram, hour×weekday heatmap
- City risk index in sidebar
- Expandable raw data table
