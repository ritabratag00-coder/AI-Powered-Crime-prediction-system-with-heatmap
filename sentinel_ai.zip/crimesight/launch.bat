@echo off
cd /d "%~dp0"
start "" /min cmd /c "python -m streamlit run app.py --server.headless true --server.port 8501"
timeout /t 4 /nobreak >nul
start "" "http://localhost:8501"